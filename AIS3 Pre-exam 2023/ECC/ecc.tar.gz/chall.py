from fastecdsa.curve import secp256k1
from fastecdsa.keys import gen_keypair
from hashlib import sha256
from itertools import count
from secrets import randbelow


def encrypt(pk, pt, nonce):
    s = nonce * pk
    c1 = s.x * pt % secp256k1.p
    c2 = nonce * secp256k1.G
    return c1, c2


def decrypt(sk, ct):
    c1, c2 = ct
    s = sk * c2
    pt = c1 * pow(s.x, -1, secp256k1.p) % secp256k1.p
    return pt


if __name__ == "__main__":
    sk, pk = gen_keypair(secp256k1)
    ct = encrypt(pk, 1234, 5678)
    assert decrypt(sk, ct) == 1234

    gen = count(randbelow(secp256k1.q), randbelow(secp256k1.q))

    secret = open("flag.txt", "rb").read().strip()
    ciphertext = [encrypt(pk, x, y) for x, y in zip(secret, gen)]
    print([(c1, c2.x, c2.y) for c1, c2 in ciphertext])
