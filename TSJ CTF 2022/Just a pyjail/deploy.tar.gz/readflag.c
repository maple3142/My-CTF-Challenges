#include <stdio.h>
#include <stdlib.h>

int main() {
	FILE *f = fopen("/flag.txt", "r");
	char buf[100];
	fread(buf, 1, 100, f);
	puts(buf);
	return 0;
}
