using Genie, Genie.Router, Genie.Renderer.Html, Genie.Requests, Genie.Sessions

upload_dir = "up"
# form = """
# <form action="/upload" method="POST" enctype="multipart/form-data">
#   <input type="file" name="file" /><br/>
#   <input type="submit" value="Submit" />
# </form>
# """

ENV["GENIE_ENV"] = "prod"

println(Genie.Configuration.env())
Genie.secret_token!(repeat("a", 64))
Sessions.init()

key32,iv16=Genie.Encryption.encryption_sauce()
println(bytes2hex(key32))
println(bytes2hex(iv16))

route("/") do
  sess = Sessions.session(params())
  println(sess.id)
  println(joinpath("sessions", sess.id))
  println(isfile(joinpath("sessions", sess.id)))
  files = Sessions.get(sess, :uploaded_files, [])
  [
    Html.div([
      span("Uploaded Files:"),
      ul(map(files) do s
        li([a(s, href=s), br()])
      end)
    ]),
    form(action="/upload", method="POST", enctype="multipart/form-data", () -> [
      input(type="file", name="file"),
      br(),
      input(type="submit", value="Upload")
    ])
  ] |> html
end

route("/upload", method = POST) do
  if infilespayload(:file)
    f = filespayload(:file)
    p = joinpath(upload_dir, basename(f.name))
    if isfile(p)
      "File already exists"
    else
      write(p, f.data)
      sess = Sessions.session(params())
      files = Sessions.get(sess, :uploaded_files, [])
      push!(files, p)
      Sessions.set!(sess, :uploaded_files, files)
      redirect(p)
    end
  else
    "No file uploaded"
  end
end

route("/up/:file") do
  p = joinpath(upload_dir, basename(payload(:file)))
  if isfile(p)
    read(p, String)
  else
    "Not Found"
  end
end

up(8891, async=false)
