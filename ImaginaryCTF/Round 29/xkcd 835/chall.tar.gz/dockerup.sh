#!/bin/sh
docker run --privileged --name xkcd_835 -p 1225:1225 -d --rm xkcd_835
