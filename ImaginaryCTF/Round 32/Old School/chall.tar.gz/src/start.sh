#!/bin/sh
chmod 4711 /readflag
chmod 600 /flag
httpd-foreground
