#include <stdio.h>

int main(){
    puts("ictf{I_hope_you_didn't_pwn_bash}");
    return 0;
}
