# About this challenge

I can't make my exploit work on Firefox 106+, so please use Firefox 105 for local testing (same as `playwright-firefox` 1.27.1). Of course it would be great if you can find a solution that works on Firefox 106+. If you can find a solution that works on latest Chromium, it would be even better (but that's too hard for me).

To test it locally, you can completely ignore the `bot_web` part. Simply edit the visited url in `bot/bot.js` and run it directly is enough and more convenient.
